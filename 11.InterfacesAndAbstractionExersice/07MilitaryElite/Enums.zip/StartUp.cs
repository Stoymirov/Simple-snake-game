﻿using MilitaryElite;

IEngine engine = new Engine();

engine.Run();
﻿using Telephony;
public interface IBrowser
{
    string Browse(string link);
}
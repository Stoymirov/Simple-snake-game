﻿using CollectionHierarchy;
using CollectionHierarchy.IO;

IEngine engine = new Engine();
engine.Run();
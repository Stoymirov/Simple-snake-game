﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ExplicitInterfaces;

    public interface IResident
    {
        string Name { get; }
        string countrey { get; }
        string GetName();
    }

